export * from "./mailRegister.template";
