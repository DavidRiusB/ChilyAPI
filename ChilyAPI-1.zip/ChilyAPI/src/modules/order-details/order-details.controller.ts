import { Controller } from '@nestjs/common';

@Controller('order-details')
export class OrderDetailsController {}
