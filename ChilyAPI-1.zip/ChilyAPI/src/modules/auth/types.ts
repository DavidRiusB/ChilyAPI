export type UserDataGoogle = {
  email: string;
  displayName: string;
};
