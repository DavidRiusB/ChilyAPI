import { Controller } from '@nestjs/common';

@Controller('delivery')
export class DeliveryController {}
