export { RemovePropertiesInterceptor } from "./remove-properties.interceptor";
