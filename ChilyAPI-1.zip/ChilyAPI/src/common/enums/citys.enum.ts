export enum City {
    Bogota = "bogota"
}