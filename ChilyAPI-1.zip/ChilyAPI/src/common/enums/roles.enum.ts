export enum Role {
  User = "user",
  Admin = "admin",
  SuperAdmin = "superadmin",
  Carrier = "carrier",
}
